#!/bin/bash

poetry install -C api