from core.callback_handler.agent_tool_callback_handler import DifyAgentCallbackHandler


class DifyWorkflowCallbackHandler(DifyAgentCallbackHandler):
    """Callback Handler that prints to std out."""
