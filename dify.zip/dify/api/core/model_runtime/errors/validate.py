class CredentialsValidateFailedError(Exception):
    """
    Credentials validate failed error
    """

    pass
