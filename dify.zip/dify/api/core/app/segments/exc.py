class VariableError(Exception):
    pass
